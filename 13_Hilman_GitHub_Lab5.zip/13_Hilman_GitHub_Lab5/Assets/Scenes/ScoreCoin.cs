﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCoin : MonoBehaviour
{

    private int speed = 2;
    public GameObject Coin;

     void Update()
    {
        Coin.transform.Rotate(0 ,speed,0 * Time.deltaTime);
    }
}