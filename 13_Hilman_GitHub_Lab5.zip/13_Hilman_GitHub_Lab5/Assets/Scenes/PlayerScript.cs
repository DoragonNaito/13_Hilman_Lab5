﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour
{
    public float speed;
    public Rigidbody playerRigidbody;
    private int Coin;
    public Text Score;

    // Start is called before the first frame update
    void Start()
    {
        playerRigidbody = GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        playerRigidbody.AddForce(movement * speed * Time.deltaTime);

    }
    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Coin")
        {
            Destroy(other.gameObject);
            Coin++;
            Score.GetComponent<Text>().text = "Coin Collected :" + Coin;
        }
        if (Coin == 4)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
        if (other.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("LoseScene");
        }
                
    }
}
    